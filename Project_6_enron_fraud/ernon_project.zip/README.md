# Detecting fraud in enron data

## The report is in machine_learning_project.pdf.

## The classifier tuning code is classifier.py, the training code is in poi_id.py and the testing code is in tester.py.